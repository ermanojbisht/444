<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEeOfficeRoadDivPivotTable extends Migration
{
    public function up()
    {
        Schema::create('ee_office_road_div', function (Blueprint $table) {
            $table->unsignedInteger('road_div_id');
            $table->foreign('road_div_id', 'road_div_id_fk_2112564')->references('id')->on('road_divs')->onDelete('cascade');
            $table->unsignedInteger('ee_office_id');
            $table->foreign('ee_office_id', 'ee_office_id_fk_2112564')->references('id')->on('ee_offices')->onDelete('cascade');
        });
    }
}

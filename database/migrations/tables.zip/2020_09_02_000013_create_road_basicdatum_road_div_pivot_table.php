<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRoadBasicdatumRoadDivPivotTable extends Migration
{
    public function up()
    {
        Schema::create('road_basicdatum_road_div', function (Blueprint $table) {
            $table->unsignedInteger('road_div_id');
            $table->foreign('road_div_id', 'road_div_id_fk_2112563')->references('id')->on('road_divs')->onDelete('cascade');
            $table->unsignedInteger('road_basicdatum_id');
            $table->foreign('road_basicdatum_id', 'road_basicdatum_id_fk_2112563')->references('id')->on('road_basicdata')->onDelete('cascade');
        });
    }
}

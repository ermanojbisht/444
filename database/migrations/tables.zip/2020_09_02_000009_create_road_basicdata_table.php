<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRoadBasicdataTable extends Migration
{
    public function up()
    {
        Schema::create('road_basicdata', function (Blueprint $table) {
            $table->increments('id');
            $table->string('road_code')->unique();
            $table->string('name');
            $table->string('road_no')->nullable();
            $table->string('type_of_road')->nullable();
            $table->string('road_sanction')->nullable();
            $table->string('connectivity_type')->nullable();
            $table->decimal('cost_in_lakh', 15, 2)->nullable();
            $table->string('data_status')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}

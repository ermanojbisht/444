<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToEeOfficesTable extends Migration
{
    public function up()
    {
        Schema::table('ee_offices', function (Blueprint $table) {
            $table->unsignedInteger('se_office_id');
            $table->foreign('se_office_id', 'se_office_fk_2112554')->references('id')->on('se_offices');
        });
    }
}

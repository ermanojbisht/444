<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAlertProjectsTable extends Migration
{
    public function up()
    {
        Schema::create('alert_projects', function (Blueprint $table) {
            $table->increments('id');
            $table->datetime('valid_upto');
            $table->string('refference_no');
            $table->decimal('amount', 15, 2)->nullable();
            $table->datetime('valid_from')->nullable();
            $table->string('contractor_details');
            $table->string('project_detail');
            $table->string('issuing_authority');
            $table->string('users')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRoadDivsTable extends Migration
{
    public function up()
    {
        Schema::create('road_divs', function (Blueprint $table) {
            $table->increments('id');
            $table->float('start_chainage', 6, 3);
            $table->float('end_chainage', 6, 3);
            $table->timestamps();
            $table->softDeletes();
        });
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToSeOfficesTable extends Migration
{
    public function up()
    {
        Schema::table('se_offices', function (Blueprint $table) {
            $table->unsignedInteger('ce_office_id');
            $table->foreign('ce_office_id', 'ce_office_fk_2112553')->references('id')->on('ce_offices');
        });
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAlertTypesTable extends Migration
{
    public function up()
    {
        Schema::create('alert_types', function (Blueprint $table) {
            $table->increments('id');
            $table->string('type')->unique();
            $table->integer('hr_before_1')->unique();
            $table->integer('hr_before_2')->nullable();
            $table->integer('hr_before_3')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToAlertProjectsTable extends Migration
{
    public function up()
    {
        Schema::table('alert_projects', function (Blueprint $table) {
            $table->unsignedInteger('alert_for_id');
            $table->foreign('alert_for_id', 'alert_for_fk_2116633')->references('id')->on('alert_types');
            $table->unsignedInteger('office_id');
            $table->foreign('office_id', 'office_fk_2116696')->references('id')->on('ee_offices');
        });
    }
}

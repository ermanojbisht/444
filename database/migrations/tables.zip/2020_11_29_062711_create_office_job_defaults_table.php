<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOfficeJobDefaultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('office_job_defaults', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('ee_office_id');
            $table->unsignedInteger('job_id');
            $table->unsignedInteger('user_id');
            $table->timestamps();
           // $table->unique('ee_office_id', 'job_id','user_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('office_job_defaults');
    }
}

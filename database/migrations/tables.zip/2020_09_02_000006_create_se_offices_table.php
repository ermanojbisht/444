<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSeOfficesTable extends Migration
{
    public function up()
    {
        Schema::create('se_offices', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name')->unique();
            $table->string('name_h')->nullable();
            $table->longText('addresss')->nullable();
            $table->integer('district')->nullable();
            $table->string('email_1')->nullable();
            $table->string('email_2')->nullable();
            $table->integer('contact_no')->nullable();
            $table->float('lat', 8, 6)->nullable();
            $table->float('lon', 8, 6)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
